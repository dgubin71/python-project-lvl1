#!/usr/bin/env python3

from brain_games.games.game_prime import prime_number


def main():
    print("Welcome to the Brain Games!")
    prime_number()


if __name__ == '__main__':
    main()
