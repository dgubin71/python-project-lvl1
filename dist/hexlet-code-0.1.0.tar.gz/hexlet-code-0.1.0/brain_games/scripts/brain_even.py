#!/usr/bin/env python3

from brain_games.game_play.game_even import even_not_even


def main():
    print("Welcome to the Brain Games!")
    even_not_even()


if __name__ == '__main__':
    main()
