#!/usr/bin/env python3

from brain_games.games.game_gcd import gcd_fun


def main():
    print("Welcome to the Brain Games!")
    gcd_fun()


if __name__ == '__main__':
    main()
